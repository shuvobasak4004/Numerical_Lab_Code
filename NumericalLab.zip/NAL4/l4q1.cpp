#include<bits/stdc++.h>
using namespace std;
float func(float a)
{

    return pow((a*a+1),0.33);
}
float fun(float a)
{

    return abs(0.33*(pow((a*a+1),(-0.667)))*2*a);
}

int main(){
   float x,d = 0.0001,xo,a;
   int i = 1;

    for(int j =-10;j<=10;j++){

       float g=fun(j);
       if(a!=100){
           if(g<1){
               a=fabs(j);

               break;
           }
       }


   }



   cout<<"a="<<a<<endl;
   //
   while(1)
   {
       x= func(xo);
       cout<<i<<" "<<xo<<" "<<x<<"\n";
       if(abs(xo-x)<=d)
       {
           break;
       }
       xo=x;

       i++;
   }
   printf("Root is = %0.3f",xo);
   return 0;
}
