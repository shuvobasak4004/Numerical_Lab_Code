#include<bits/stdc++.h>
using namespace std;
float func(float a)
{

    return (exp(a)/3.0);
}
int main(){
   float x,d = 0.0001,xo,a;
   int i = 1;
   //cout<<"Enter initial value of x :"<<endl;
   //cin>>xo;

   //

    for(int j =-10;j<=10;j++){
       float g=func(j);
       if(a!=100){
           if(g<1){
               a=abs(j);

               break;
           }
       }


   }
   cout<<"a="<<a<<endl;
   //
   while(1)
   {
       x= func(xo);
       cout<<i<<" "<<xo<<" "<<x<<"\n";
       if(abs(xo-x)<=d)
       {
           break;
       }
       xo=x;

       i++;
   }
   printf("Root is = %0.3f",xo);
   return 0;
}

