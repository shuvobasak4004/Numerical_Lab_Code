#include<bits/stdc++.h>
using namespace std;
float func(float a)
{
    return (4*exp(-a)*sin(a)-1);
}
int main(){
   float a=0 , b=0.5,x,d = 0.0001,k;
   int i = 1;
   //cout<<"Enter a and b :"<<endl;
   /*
   for(int j =-10;j<=10;j++){
       float g=func(j);
       if(a!=100){
           if(g>=0){
               a=j-1;
               b=j;
               break;
           }
       }
       if(b!=100){
           if(g<0){
               a=j;
               b=j+1;
               break;
           }
       }
       if(g<0){
           a=j;
       }else{
           b=j;
       }

   }
   cout<<"a="<<a<<endl<<"b="<<b<<endl;
   */

   cout<<"SL     "<<"    a   "<<"    b   "<<"    X   "<<"      f(X)   \n";
   while(1)
   {
             x=((a*func(b)-b*func(a)))/((func(b)-func(a)));
       cout<<i<<" "<<a<<" "<<b<<" "<<x<<" "<<func(x)<<"\n";
       if(func(x)>0)
       {
           b=x;
       }
       else{
        a=x;
       }
       k=((a*func(b)-b*func(a)))/((func(b)-func(a)));
       if(abs(x-k)<=d)
       {
           break;
       }
       i++;
   }
   printf("Root is = %0.3f",x);
   return 0;
}



