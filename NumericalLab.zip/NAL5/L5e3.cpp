//problem 3
#include<bits/stdc++.h>

using namespace std;

float func(float x)
{
    return (x-sin(x)-0.5);
}
float der(float x)
{
  return (1-cos(x));
}
int main()
{

   float x0=1,x1,a,b,d=0.001;
   int i =1;
   cout<<"X0="<<x0<<endl;


    while(1)
    {
        a=func(x0);
        b=der(x0);
        x1=x0-(a/b);
         cout<<i<<"\t"<<x0<<"\t"<<x1<<endl;
        if(abs(x0-x1)<=d)
        {
            break;
        }
        x0=x1;
        i++;

    }
    cout<<endl<<x0<<endl;

    return 0;
}


