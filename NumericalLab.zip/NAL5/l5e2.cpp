//prob 2
#include<bits/stdc++.h>

using namespace std;

float func(float x)
{
    return (exp(x)-3*x);


}
float der(float x)
{
     return (exp(x)-3);


}
int main()
{

   float x0=0.5,x1,a,b,d=0.001;
   int i =1;
   cout<<"X0="<<x0<<endl;


    while(1)
    {
        a=func(x0);
        b=der(x0);
        x1=x0-(a/b);
        cout<<i<<"\t"<<x0<<"\t"<<x1<<endl;
        if(abs(x0-x1)<=d)
        {
            break;
        }
        x0=x1;
        i++;

    }
    cout<<endl<<x0<<endl;

    return 0;
}


