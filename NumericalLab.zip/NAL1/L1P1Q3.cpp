//19204004-Shuvo-04
/*
Write a C/C++ program to find the real roots of a quadrature
equation such as- 𝑥2 + 2𝑥 − 15 = 0
*/
#include<bits/stdc++.h>
using namespace std;
void dg0(float a,float b, float c);
void de0(float a,float b, float c);
void dl0(float a,float b, float c);
int main()
{
    float a,b,c,d,e,x1,x2;

    cout<<"Enter a= ";
    cin>>a;
    cout<<"Enter b= ";
    cin>>b;
    cout<<"Enter c= ";
    cin>>c;

    d = b*b - 4*a*c;

    if(d>0)
    {
        dg0(a,b,c);
    }
    else if(d==0)
    {
        de0(a,b,c);
    }
    else
    {
        dl0(a,b,c);
    }


    cout<<"\n\n Done \n\n"<<endl;
    return 0;
}

void dg0(float a,float b, float c){

    cout<<" dg0\n"<<endl;
    float x1,x2,discriminant;
    discriminant = b*b - 4*a*c;

        x1 = (-b + sqrt(discriminant)) / (2*a);
        x2 = (-b - sqrt(discriminant)) / (2*a);
        cout << "Roots are real and different." << endl;
        cout << "x1 = " << x1 << endl;
        cout << "x2 = " << x2 << endl;

}
void de0(float a,float b, float c){
cout<<" de0\n"<<endl;
        float x1,x2,discriminant;
        discriminant = b*b - 4*a*c;
        cout << "Roots are real and same." << endl;
        x1 = -b/(2*a);
        cout << "x1 = x2 =" << x1 << endl;
}
void dl0(float a,float b, float c){
    cout<<" dl0\n";

    float  x1, x2, discriminant, realPart, imaginaryPart;

    discriminant = b*b - 4*a*c;


        realPart = -b/(2*a);
        imaginaryPart =sqrt(-discriminant)/(2*a);
        cout << "Roots are complex and different."  << endl;
        cout << "x1 = " << realPart << "+" << imaginaryPart << "i" << endl;
        cout << "x2 = " << realPart << "-" << imaginaryPart << "i" << endl;
}
