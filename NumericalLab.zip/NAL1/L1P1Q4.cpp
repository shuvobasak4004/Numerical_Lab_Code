#include<bits/stdc++.h>
using namespace std;


int main()
{
    float Ea, Er, Ep, x, x1;
    cout<<"enter True Value:";
    cin>>x;
    cout<<"enter Approximate Value:";
    cin>>x1;

    Ea = x - x1;
    cout<<fixed;

    cout<<setprecision(3)<<"Absolute error:"<<Ea<<endl;

    Er = Ea / x;
    cout<<fixed;
    cout<<setprecision(3)<<"Relative error:"<<Er<<endl;

    Ep = 100 * Er;
    cout<<fixed;

    cout<<setprecision(3)<<"percentage error:"<<Ep<<endl;

    return 0;



}
