#include<bits/stdc++.h>
using namespace std ;
int main()
{
    int a, n,i,flag = 0,j,l;
    cout<<"Enter a :: ";
    cin>>a;
    cout<<"Enter l :: ";
    cin>>l;

    for(j=a;j<=l;j++)
    {
        n=j;
        flag = 0;

    for(i=2;i<=n/2;i++)
    {
        if(n%i==0)
        {
            flag = 1;
          break;
        }


    }





      if(flag == 0)
        {
            cout<<"Prime ="<<n<<endl;
        }

    }



        return 0;
}
