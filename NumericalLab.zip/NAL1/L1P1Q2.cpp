#include<bits/stdc++.h>
using namespace std;
void func(int a);
int main()
{
    int a;
    cout<<"Enter :";
    cin>>a;
    cout<<endl;
    func(a);
    return 0;
}
void func(int a){
for(int i = 1; i <= a; ++i)
    {
        for(int j = 1; j <= i; ++j)
        {
            cout << "* ";
        }
        cout << "\n";
    }
}
