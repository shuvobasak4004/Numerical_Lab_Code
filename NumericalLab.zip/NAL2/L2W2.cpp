#include<bits/stdc++.h>
using namespace std;
float func(float a)
{
    return (a*exp(a)-1);
}
int main(){
   float a=0 , b=1,x,d = 0.05,k,x1,x2,E1;
   int i = 1;
   //cout<<"Enter a and b :"<<endl;
   /*
   for(int j =-10;j<=10;j++){
       float g=func(j);
       if(a!=100){
           if(g>=0){
               a=j-1;
               b=j;
               break;
           }
       }
       if(b!=100){
           if(g<0){
               a=j;
               b=j+1;
               break;
           }
       }
       if(g<0){
           a=j;
       }else{
           b=j;
       }

   }
   cout<<"a="<<a<<endl<<"b="<<b<<endl;
   */

   cout<<"SL     "<<"    a   "<<"    b   "<<"    X   "<<"      f(X)   \n";
   while(1)
   {
       x= (a+b)/2;
       cout<<i<<" "<<a<<" "<<b<<" "<<x<<" "<<func(x)<<"\n";
       if(func(x)>0)
       {
           b=x;
       }
       else{
        a=x;
       }
       k=(a+b)/2;
       E1 = ((abs(k - x) / k) * 100.0);
       cout<<"E = "<<E1<<endl;
       if(E1<=d)
       {
           break;
       }
       i++;
   }

   //x1 = (0 + 1) / 2.0;
   //printf("x1=%0.2f\n", x1);
   //x2 = (x1 + 1) / 2.0;
   //printf("x2=%0.2f\n", x2);
   E1 = ((abs(x2 - x1) / x2) * 100.0);

   //printf("tolerance is:%f\n", E1);
   printf("Root is = %0.3f",x);
   cout<<endl<<endl;

   return 0;
}



